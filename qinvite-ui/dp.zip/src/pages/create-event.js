import React, {Component} from 'react';
import TextField from 'material-ui/TextField';
import DatePicker from 'material-ui/DatePicker';
import AutoComplete from 'material-ui/AutoComplete';
import RaisedButton from 'material-ui/RaisedButton';
import IconButton from 'material-ui/IconButton';
import FontIcon from 'material-ui/FontIcon';
import ExpandTransition from 'material-ui/internal/ExpandTransition';
import {CopyToClipboard} from 'react-copy-to-clipboard';

import {
    Step,
    Stepper,
    StepLabel,
    StepContent
  } from 'material-ui/Stepper';

import LocationList from '../partials/location-list';

import './create-event.css';


export default class CreateEventPage extends Component{
    constructor(props){
        super(props);
        this.state = {
            locationSuggestions:[
                {name:"Thor",image:"https://upload.wikimedia.org/wikipedia/en/thumb/f/fc/Thor_poster.jpg/220px-Thor_poster.jpg"},
                {name:"Thor Ragnarok",image:"https://images-na.ssl-images-amazon.com/images/M/MV5BMjMyNDkzMzI1OF5BMl5BanBnXkFtZTgwODcxODg5MjI@._V1_UY1200_CR90,0,630,1200_AL_.jpg"},
                {name:"LuLu Mall",image:"https://upload.wikimedia.org/wikipedia/commons/thumb/1/16/Lulumall_atrium.JPG/220px-Lulumall_atrium.JPG"},
                {name:"PVR Cinemas",image:"https://www.keralatalkies.info/media/2013/04/PVR-Cinemas-at-LuLu-Mall.jpg"},
            ],
            loading: false,
            stepIndex: 0,
            finished: false,
            selected: 1,
            buttonLabel: "Next",
            linkValue:'http://qinvte.com/event/123445',
            copied: false
        };
        this.handleLocationInput = this.handleLocationInput.bind(this);
        this.dummyAsync = this.dummyAsync.bind(this);
        this.handleNext = this.handleNext.bind(this);
    }


    handleLocationInput(value){
        this.setState({
            ...this.state,
            locationSuggestions:[
                value + "1",
                value + " 2 " + value,
                value + " 3 " + value,
            ]
        });
    }

    dummyAsync(cb){
        this.setState({...this.state,loading: true}, () => {
          this.asyncTimer = setTimeout(cb, 500);
        //   console.log("loading true");
        });
      };

    handleNext(){
        const {stepIndex} = this.state;
        if( !this.state.loading){
            console.log("handle next")
            this.dummyAsync(() => this.setState({
                ...this.state,
                loading: false,
                stepIndex: stepIndex+1,
                finished: stepIndex >= 2,
                buttonLabel: stepIndex == 1?"Confirm":"Next"
            }))
        }
    }

    handlePrev(){
        const {stepIndex} = this.state;
        if(!this.state.loading){
            this.setState({
                ...this.state,
                loading:false,
                stepIndex: stepIndex - 1,
                buttonLabel: stepIndex == 2?"Confirm":"Next"
            });
        }
    }


    getStepContent(index){

        switch(index){
            case 0: 
                return(
                    <div>
                        <TextField 
                        floatingLabelText="Event Title"
                        hintText="Awesome event" />
                        <br/>
                        <DatePicker floatingLabelText="Event Date" hintText="Pick a date" />
                        <br/>
                        <TextField 
                        hintText="Event Description"
                        multiLine={true}
                        rowsMax={4} />
                        <br/>
                        
                    </div>
                );
            case 1: 
                return (
                    <div>
                        <AutoComplete
                        hintText="Where.."
                        floatingLabelText="Location"
                        dataSource={this.state.locationSuggestions}
                        onUpdateInput={this.handleLocationInput}
                        /> 
                        <LocationList
                             selected={this.state.selected}
                             suggestions={this.state.locationSuggestions}/>
                    </div>
                );
            case 2:
                return (
                    <div>
                        <TextField 
                        hintText="Email your Friends"
                        multiLine={true}
                        rowsMax={4} />
                    </div>
                );
            
            default:
                return (
                    <div className="link-container">
                        <CopyToClipboard text={this.state.linkValue}
                            onCopy={() => this.setState({...this.state,copied:true})}
                        >
                            <span className="link-spot">{this.state.linkValue}</span>
                            
                            
                            
                        </CopyToClipboard>
                        <span className="tooltip-link">{this.state.copied?"Copied":"Click to Copy"}</span>
                    </div>
                );
        }
    }



    renderHorizontal(){

        const contentStyle = {margin: '0 16px', overflow: 'hidden'};
        
        const { stepIndex,finished } = this.state;
        
        return(
            <div>
                <Stepper activeStep={stepIndex} >
                    <Step>
                        <StepLabel>Name your Event</StepLabel>
                    </Step>
                    <Step>
                        <StepLabel>Fill in Details</StepLabel>
                    </Step>
                    <Step>
                        <StepLabel>Invite Your Friends</StepLabel>
                    </Step>
                </Stepper>

                <ExpandTransition loading={this.state.loading} open={true}>
                    <div style={contentStyle}>
                        <div>{this.getStepContent(stepIndex)}</div> 
                    </div>
                </ExpandTransition>
                <RaisedButton
                    style={{
                        color:"#fff",
                        marginTop: "10px"
                    }}
                    disabled={finished}
                    secondary={true}
                    label={this.state.buttonLabel}
                    onClick={() => {
                        if(!finished){
                            this.handleNext();console.log("handle")}; console.log("clicked")}}
                /> 
            </div>
        );
    }

    renderVertical(){
        const { stepIndex,finished } = this.state;

        return(
            <div>
                <Stepper activeStep={stepIndex} orientation="vertical">            
                    {["Name your Event","Fill in Details","Invite your Friends"].map((el,e) => (
                        <Step key={e}>
                            <StepLabel>{el}</StepLabel>
                            <StepContent>
                                {this.getStepContent(e)}
                                <RaisedButton
                                    style={{
                                        color:"#fff",
                                        marginTop: "10px"
                                    }}
                                    disabled={finished}
                                    secondary={true}
                                    label="Next"
                                    onClick={() => {
                                        if(!finished){
                                            this.handleNext();console.log("handle")}; console.log("clicked")}}
                                /> 
                            </StepContent>
                        </Step>
                        ))}
                </Stepper>
            </div>
        );
    }

    render(){

        const { stepIndex } = this.state;
        const content = document.body.clientWidth>500?this.renderHorizontal():this.renderVertical();
        return(
            <div className="container-fluid">
                <br/>
                <div className="col-sm-12">
                    <h2>New Event</h2>
                </div>
                <div className="col-sm-12">
                    
                    {/* <TextField 
                        hintText="Event Description"
                        multiLine={true}
                        rows={1}
                        rowsMax={5}/>       
                    <br/>
                    <AutoComplete
                        hintText="Where.."
                        floatingLabelText="Location"
                        dataSource={this.state.locationSuggestions}
                        onUpdateInput={this.handleLocationInput}
                        />  
                    <br/> */}

                    {content}

                    


                              
                </div>
            </div>
        );
    }
}