export const Auth = 'http://localhost:8000/auth/';
export const CreateUser = 'http://localhost:8000/users/';